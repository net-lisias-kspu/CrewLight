﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CrewLight
{
	[KSPAddon(KSPAddon.Startup.Flight, false)]
	public class CrewLight : MonoBehaviour
	{
		/*
		 * 
		 *	This little plugin does two things : when a vessel is selected, all the part containing a Kerbal
		 *	are lightnend.
		 *	Second : when a Kerbal change seat, either by a transfer or boarding the corresponding part is 
		 *	lightned.
		 * 
		 */

		public void Start () {
			GameEvents.onCrewTransferred.Add (UpdateLight);
			GameEvents.onVesselChange.Add (StartLight);
			StartCoroutine ("RoutineLight");
		}

		public void OnDestroy () {
			GameEvents.onCrewTransferred.Remove (UpdateLight);
			GameEvents.onVesselChange.Remove (StartLight);
		}

		IEnumerator RoutineLight () {
			Vessel vessel = FlightGlobals.ActiveVessel;
			if (vessel.crewedParts != 0 && vessel.isEVA == false) {
				yield return new WaitForSeconds (.1f);
				StartLight (vessel);
			}
		}

		private void UpdateLight (GameEvents.HostedFromToAction<ProtoCrewMember, Part> eData) {
			/* Update the status of the lights when a Kerbal moves */
			Light (eData.to);
		}

		private void StartLight (Vessel vessel) {
			/* Set the lights when a vessel is selected */
			List<ProtoCrewMember> crewList = vessel.GetVesselCrew ();

			for (int i = 0 ; i < crewList.Count ; i++){
				if (crewList[i].KerbalRef != null) {// If this is false it should means the Kerbal is in a Command Seat
					Light (crewList[i].KerbalRef.InPart);
				}
			}
		}

		private void Light (Part part) {
			/* Send the event that turn on the light, different flavor for different PartModule */
			if (part.Modules.Contains<ModuleColorChanger>()) {
				List<ModuleColorChanger> animList = part.Modules.GetModules<ModuleColorChanger> ();
				for (int i = 0; i < animList.Count; i++) {
					if (animList [i].toggleName == "Toggle Lights" && animList[i].animState == false) {
						animList [i].ToggleEvent ();
						Debug.Log ("[Crew Light] : " + part.name + " is lighted by ModuleColorChanger");
						return;
					}
				}
			}
			if (part.Modules.Contains<ModuleAnimateGeneric> ()) {
				List<ModuleAnimateGeneric> animList = part.Modules.GetModules<ModuleAnimateGeneric> ();
				for (int i = 0; i < animList.Count; i++) {
					if (animList [i].actionGUIName == "Toggle Lights" && animList [i].animSwitch == true) {
						animList [i].Toggle ();
						Debug.Log ("[Crew Light] : " + part.name + " is lighted by ModuleAnimateGeneric");
						return;
					}
				}
			}
			if (part.Modules.Contains<ModuleLight>()) { // For the Karibou rover, and maybe others...
				List<ModuleLight> animList = part.Modules.GetModules<ModuleLight> ();
				for (int i = 0; i < animList.Count; i++) {
					if (animList [i].isOn == false) {
						animList [i].LightsOn ();
						Debug.Log ("[Crew Light] : " + part.name + " is lighted by ModuleLight");
						return;
					}
				}
			}
		}
	}
}

